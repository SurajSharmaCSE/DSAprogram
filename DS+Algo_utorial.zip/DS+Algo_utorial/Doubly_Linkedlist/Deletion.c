#include<stdio.h>
#include<stdlib.h>

struct Node
{
    int data;
    struct Node *prev;
    struct Node *Next;
};

void LinkedTravers(struct Node *ptr)
{
    while(ptr!=NULL)
    {
        printf("Element:%d\n",ptr->data);
        ptr=ptr->Next;
    }
}

void ReverseTravers(struct Node *ptr)
{

    struct Node *tail=ptr;
    while(tail->Next !=NULL)
    {
        tail=tail->Next;
    }

    do
    {
        printf("Element:%d\n",tail->data);
        tail=tail->prev;
    } while (tail!=ptr);

    printf("Element:%d\n",tail->data);
    

}

//Deletion Start --->

struct Node * DeleteAtBeginning(struct Node *head)
{
    struct Node *temp=head;
    head=head->Next;
    temp->Next=NULL;
    head->prev=NULL;
    free(temp);

    return head;

}

struct Node * DeleteAtEnd(struct Node *head)
{
    struct Node *temp=head;

    while(temp->Next!=NULL)
    {
        temp=temp->Next;

    }
    temp->prev->Next=NULL;
    free(temp);
    return head;
    
}

struct Node * DeleteAtIndex(struct Node *head,int index)
{
   struct Node *temp=head;
   struct Node *temp2;
  for(int i=0;i<index-1;i++)
   {
       temp=temp->Next;
    
   }
   temp2=temp->prev;
   temp2->Next=temp->Next;
   temp->Next->prev=temp2;
   free(temp);
   temp=NULL;

   return head;
   
   
}



//Deletion End --->

int main()
{
    struct Node *n1;
    struct Node *n2;
    struct Node *n3;
    struct Node *n4;

    n1=(struct Node *) malloc(sizeof(struct Node));
    n2=(struct Node *) malloc(sizeof(struct Node));
    n3=(struct Node *) malloc(sizeof(struct Node));
    n4=(struct Node *) malloc(sizeof(struct Node));
    //link first and second node
    n1->data=10;
    n1->prev=NULL;
    n1->Next=n2;

    //link second and 3rd node
    n2->data=20;
    n2->prev=n1;
    n2->Next=n3;

    //link 3rd and forth

    n3->data=30;
    n3->prev=n2;
    n3->Next=n4;

    //terminate fourth element

    n4->data=40;
    n4->prev=n3;
    n4->Next=NULL;
    // ReverseTravers(n1);
     
    printf("Before Deletion:\n");
    LinkedTravers(n1);

    printf("After Deltion\n");
    // n1=DeleteAtBeginning(n1);
    //    n1=DeleteAtEnd(n1);
    n1=DeleteAtIndex(n1,2);
    LinkedTravers(n1);
    

}