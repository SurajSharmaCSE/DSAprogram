#include<stdio.h>
#include<stdlib.h>

struct Node
{
    int data;
    struct Node *prev;
    struct Node *Next;
};

void LinkedTravers(struct Node *ptr)
{
    while(ptr!=NULL)
    {
        printf("Element:%d\n",ptr->data);
        ptr=ptr->Next;
    }
}

void ReverseTravers(struct Node *ptr)
{

    struct Node *tail=ptr;
    while(tail->Next !=NULL)
    {
        tail=tail->Next;
    }

    do
    {
        printf("Element:%d\n",tail->data);
        tail=tail->prev;
    } while (tail!=ptr);

    printf("Element:%d\n",tail->data);
    

}

//Insertion start -->

struct Node * InsertAtBegining(struct Node *head,int data)
{
    struct Node *new=(struct Node *)malloc(sizeof(struct Node));
    new->data=data;
    new->prev=NULL;
    new->Next=head;
    head->prev=new;
    head=new;

}

struct Node * InsertAtSpecific(struct Node *head,int index,int data)
{
     struct Node *newNode=(struct Node *)malloc(sizeof(struct Node));
     struct Node *temp=head;
     newNode->data=data;

     int i=0;
     while(i!=index-1)
     {
        temp=temp->Next;
        i++;

     }

     newNode->Next=temp->Next;
     temp->Next->prev=newNode;

     temp->Next=newNode;
     newNode->prev=temp;
     
}

struct Node * InsertAtEnd(struct Node *head,int data)
{
    struct Node *new=(struct Node *)malloc(sizeof(struct Node));
    struct Node *ptr=head;
    new->data=data;
    new->Next=NULL;
    while (ptr->Next!=NULL)
    {
        ptr=ptr->Next;
    }
    new->prev=ptr;
    ptr->Next=new;
    ptr=new;
    
    
}

//Insertion End --->

int main()
{
    struct Node *n1;
    struct Node *n2;
    struct Node *n3;
    struct Node *n4;

    n1=(struct Node *) malloc(sizeof(struct Node));
    n2=(struct Node *) malloc(sizeof(struct Node));
    n3=(struct Node *) malloc(sizeof(struct Node));
    n4=(struct Node *) malloc(sizeof(struct Node));
    //link first and second node
    n1->data=10;
    n1->prev=NULL;
    n1->Next=n2;

    //link second and 3rd node
    n2->data=20;
    n2->prev=n1;
    n2->Next=n3;

    //link 3rd and forth

    n3->data=30;
    n3->prev=n2;
    n3->Next=n4;

    //terminate fourth element

    n4->data=40;
    n4->prev=n3;
    n4->Next=NULL;
    // ReverseTravers(n1);

    printf("Before Insertion\n:");
    LinkedTravers(n1);

    printf("After Insertion:\n");
    // n1=InsertAtBegining(n1,5);
    // n1=InsertAtEnd(n1,220);
    n1=InsertAtSpecific(n1,3,2000);
      LinkedTravers(n1);
    
}