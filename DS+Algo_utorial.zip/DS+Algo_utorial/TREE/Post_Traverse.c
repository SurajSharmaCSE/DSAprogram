#include<stdio.h>
#include<malloc.h>

struct node
{
    int data;
    struct node *left;
    struct node *right
};

struct node * CreateNode(int data)
{
    struct node *p=(struct node *)malloc(sizeof(struct node));
    p->data=data;
    p->left=NULL;
    p->right=NULL;

    return p;
}

void PostOrder(struct node * r)
{
    if(r!=NULL)
     {
         PostOrder(r->left);
         PostOrder(r->right);
         printf("%d ",r->data);
     }
}

int main()
{
    struct node *root = CreateNode(4);
    struct node *n1 = CreateNode(1);
    struct node *n2 = CreateNode(6);
    struct node *n3 = CreateNode(5);
    struct node *n4 = CreateNode(2);
    

    root->left=n1;
    root->right=n2;

    n1->left=n3;
    n1->right=n4;

   
    PostOrder(root);
    return 0;
}