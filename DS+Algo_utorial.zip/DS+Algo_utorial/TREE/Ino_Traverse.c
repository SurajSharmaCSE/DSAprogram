#include<stdio.h>
#include<malloc.h>

struct node
{
    int data;
    struct node *left;
    struct node *right
};

struct node * CreateNode(int data)
{
    struct node *p=(struct node *)malloc(sizeof(struct node));
    p->data=data;
    p->left=NULL;
    p->right=NULL;

    return p;
}

int IsBST(struct node * r)
{
    static struct node *prev=NULL;
    if(r!=NULL)
    {
         if(!IsBST(r->left))
         {
            return 0;
         }
         if(prev!=NULL && r->data <= prev->data)
         {
             return 0;
         
         }
         prev=r;
         return IsBST(r->right);

    }
    else
    {
        return 1;
    }

}

int main()
{
    struct node *root = CreateNode(5);
    struct node *n1 = CreateNode(9);
    struct node *n2 = CreateNode(1);
    struct node *n3 = CreateNode(1);
    struct node *n4 = CreateNode(4);
    

    root->left=n1;
    root->right=n2;

    n1->left=n3;
    n1->right=n4;

   
    if(IsBST(root))
    {
        printf("It is BST");
    }
    else
    {
        printf("It is not BST");
    }
    return 0;
}