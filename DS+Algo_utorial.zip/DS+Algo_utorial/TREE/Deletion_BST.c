#include<stdio.h>
#include<malloc.h>

struct node
{
    int data;
    struct node * left;
    struct node * right;
};

struct node * CreateNode(int data)
{
   struct node * newNode=(struct node *)malloc(sizeof(struct node));
   newNode->data=data;
   newNode->left=NULL;
   newNode->right=NULL;
}

void inOrder(struct  node* root){
    if(root!=NULL){
        inOrder(root->left);
        printf("%d ", root->data);
        inOrder(root->right);
    }
}
 

struct node *inOrderPredecessor(struct node* root){
    root = root->left;
    while (root->right!=NULL)
    {
        root = root->right;
    }
    return root;
}

struct node * DeletionNode(struct node *root,int value)
{
    struct node * iPre;
    if(root==NULL)
    {
        return NULL;
    }

    if (root->left==NULL && root->right==NULL)
    {
        free(root);
        return NULL;
    }

    
    if (value<root->data)
    {
        root->left=DeletionNode(root->left,value);

    }
    else if(value>root->data)
    {
        root->right=DeletionNode(root->right,value);
    }

    else
    {
        iPre= inOrderPredecessor(root);
        root->data = iPre->data;
        DeletionNode(root->left, iPre->data);
    }
    
    
}

int main()
{
    //Node Creation
    struct node *Root=CreateNode(5);
    struct node *p1=CreateNode(3);
    struct node *p2=CreateNode(6);
    struct node *p3=CreateNode(1);
    struct node *p4=CreateNode(4);

    //node LInking
    Root->left=p1;
    Root->right=p2;
    p1->left=p3;
    p1->right=p4;

    inOrder(Root);
    printf("\n");
    DeletionNode(Root,5);
    inOrder(Root);

    return 0;
}