// #include<stdio.h>
// #include<malloc.h>

// struct node
// {
//     int data;
//     struct node *left;
//     struct node *right;
// };

// struct node * CreateNode(int data)
// {
//     struct node *p=(struct node *)malloc(sizeof(struct node));
//     p->data=data;
//     p->left=NULL;
//     p->right=NULL;

//     return p;
// }

// void Insert(struct node * r,int key)
// {
//   struct node *prev=NULL;
//  while(r!=NULL)
//  {
//      prev=r;
//     if(key==r->data)
//     {
//         printf("Insertion not allow For dublicate data");
//     }
//     else if (key<r->data)
//     {
//         r=r->left;
//     }
//     else
//     {
//         r=r->right;
//     }

//  }

//  struct node* new=CreateNode(key);
//   if(new<prev->data)
//   {
//      r->left=new;
//   }
//  else
//  {
//      r->right=new;
//  }
    
// }

// void PostOrder(struct node * r)
// {
//     if(r!=NULL)
//      {
//          printf("%d ",r->data);
//          PostOrder(r->left);
//          PostOrder(r->right);
//      }
// }

// int main()
// {
//     struct node *root = CreateNode(5);
//     struct node *n1 = CreateNode(9);
//     struct node *n2 = CreateNode(1);
//     struct node *n3 = CreateNode(1);
//     struct node *n4 = CreateNode(4);
    

//     root->left=n1;
//     root->right=n2;

//     n1->left=n3;
//     n1->right=n4;

   
//     Insert(root,16);

//     PostOrder(root);

//     return 0;
// }








#include<stdio.h>
#include<malloc.h>

struct node{
    int data;
    struct node* left;
    struct node* right;
};

struct node* createNode(int data){
    struct node *n; // creating a node pointer
    n = (struct node *) malloc(sizeof(struct node)); // Allocating memory in the heap
    n->data = data; // Setting the data
    n->left = NULL; // Setting the left and right children to NULL
    n->right = NULL; // Setting the left and right children to NULL
    return n; // Finally returning the created node
}


void insert(struct node *root, int key){
   struct node *prev = NULL;
   while(root!=NULL){
       prev = root;
       if(key==root->data){
           printf("Cannot insert %d, already in BST", key);
           return;
       }
       else if(key<root->data){
           root = root->left;
       }
       else{
           root = root->right;
       }
   }
   struct node* new = createNode(key);
   if(key<prev->data){
       prev->left = new;
   }
   else{
       prev->right = new;
   }

}

int main(){
     
    // Constructing the root node - Using Function (Recommended)
    struct node *p = createNode(5);
    struct node *p1 = createNode(3);
    struct node *p2 = createNode(6);
    struct node *p3 = createNode(1);
    struct node *p4 = createNode(4);
    // Finally The tree looks like this:
    //      5
    //     / \
    //    3   6
    //   / \
    //  1   4  

    // Linking the root node with left and right children
    p->left = p1;
    p->right = p2;
    p1->left = p3;
    p1->right = p4;

    insert(p, 16);
    printf("%d", p->right->right->data);
    return 0;
}
