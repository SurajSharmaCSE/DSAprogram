#include<stdio.h>
#include<malloc.h>

struct node
{
    int data;
    struct node *left;
    struct node *right
};

struct node * CreateNode(int data)
{
    struct node *p=(struct node *)malloc(sizeof(struct node));
    p->data=data;
    p->left=NULL;
    p->right=NULL;

    return p;
}

void PrintTreeData(struct node * r)
{
    if(r!=NULL)
     {
         printf("%d ",r->data);
         PrintTreeData(r->left);
         PrintTreeData(r->right);
     }
}

int main()
{
    struct node *root=CreateNode(2);
    struct node *n1=CreateNode(1);
    struct node *n2=CreateNode(4);

    root->left=n1;
    root->right=n2;
    PrintTreeData(root);
    return 0;
}