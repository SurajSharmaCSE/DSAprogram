#include<stdio.h>

void printArray(int *A,int size)
{
    for (int i = 0; i < size-1; i++)
    {
        printf("%d ",A[i]);
    }

    printf("\n");
    
}

void BubleSort(int *A,int size)
{
    int temp;
    for (int i = 0; i < size-1; i++)  //for passes
    {
        for (int j= 0; j < size-1-i; j++) // for each phase
        {
            if (A[j]>A[j+1])
            {
               temp=A[j];
               A[j]=A[j+1];
               A[j+1]=temp;
            }
            
        }
        
    }
    
}

void BubleSortAdaptive(int *A,int size)
{
    int temp,isSorted=0;
    for (int i = 0; i < size-1; i++)  //for passes
    {
        printf("Working on pass number %d\n", i+1);
        isSorted = 1;
        for (int j= 0; j < size-1-i; j++) // for each phase
        {
            if (A[j]>A[j+1])
            {
               temp=A[j];
               A[j]=A[j+1];
               A[j+1]=temp;
            }
            
        }

        if(isSorted){
            return;
        
    }
    
}

int main()
{
    // int arr[]={12,2,34,3,23,15,22,45,76,87,12,22,333,9,78,1,3,4,5,6};
    int arr[]={1,2,3,4,5,6,7,8,9};
    int n=9;
    printArray(arr,n);
    BubleSortAdaptive(arr,n);
    printArray(arr,n);
    return 0;
}