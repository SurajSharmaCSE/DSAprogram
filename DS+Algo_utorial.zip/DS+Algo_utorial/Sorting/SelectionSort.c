#include<stdio.h>

void SeletionSort(int *A,int Size)
{
    int indexMin,temp;
    for (int i =0; i <Size-1; i++)
    {
        indexMin=i;
        for (int j = i+1; j <Size; j++)
        {
            if(A[j]<A[indexMin])
             {
                 indexMin=j;
             }
        }

        // Swap A[i] and indexMin
        
        temp=A[i];
        A[i]=A[indexMin];
        A[indexMin]=temp;
        
    }
    
}

void printArray(int* A, int n){
    for (int i = 0; i < n; i++)
    {
        printf("%d ", A[i]);
    }
    printf("\n");
}

int main()
{
    int A[] = {12, 54, 65, 7, 23, 9};
    int n = 6;
    printArray(A, n);
    SeletionSort(A, n);
    printArray(A, n);
    return 0;
}