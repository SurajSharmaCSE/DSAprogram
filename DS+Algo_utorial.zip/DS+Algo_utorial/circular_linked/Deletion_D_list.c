#include<stdio.h>
#include<stdlib.h>

struct node
{
    int data;
    struct node * next;
};

void traversal(struct node *head)
{
    struct node *ptr=head;
    do
    {
        printf("Element: %d\n",ptr->data);
        ptr=ptr->next;
    } while (ptr!=head);
    

}

//Deletion Operation Start
struct node * DeleteAtFirst(struct node *head)
{
    struct node * travers=head->next;
    struct node *temp=head;

    while(travers->next!=head)
    {
        travers=travers->next;
    }
    travers->next=temp->next;
    head=travers->next;
    free(temp);
    return head;
    

}

struct node * DeleteAtIndex(struct node *head,int index)
{
    struct node *p=head;
    struct node *q=head->next;
      
    for (int i = 0; i < index-1; i++)
    {
        p=p->next;
        q=q->next;
    }
    p->next=q->next;
    free(q);
    return head;
    
}

struct node * DeleteAtEnd(struct node *head)
{
    struct node *ptr=head;
    struct node *temp=head->next;
    
    while(temp->next!=head)
    {   
        temp=ptr;
        ptr=ptr->next;
    }
    ptr->next=head;
    
    free(temp);



}

int main()
{
    struct node *Ist;
    struct node *IInd;
    struct node *IIIrd;
    struct node *IVth;

    Ist=(struct node *) malloc(sizeof(struct node));
    IInd=(struct node *) malloc(sizeof(struct node));
    IIIrd=(struct node *) malloc(sizeof(struct node));
    IVth=(struct node *) malloc(sizeof(struct node));

    //link 1st and 2nd;
     Ist->data=10;
     Ist->next=IInd;
    
    //link 2nd and 3rd
    IInd->data=20;
    IInd->next=IIIrd;

    //link 3rd and 4th node
     IIIrd->data=30;
     IIIrd->next=IVth;

     //terminate 4th node;
     IVth->data=40;
     IVth->next=Ist;
     
     printf("Before Deletion\n");
     traversal(Ist);

     printf("After Deletion\n");
    //  Ist=DeleteAtFirst(Ist);
        // Ist=DeleteAtIndex(Ist,1);
        Ist=DeleteAtEnd(Ist);
        traversal(Ist);
        return 0;




}