#include<stdio.h>
#include<stdlib.h>

struct Node
{
    int data;
    struct Node *next;
};

void Traversal(struct Node *head)
{
    struct Node *ptr=head;
    do
    {
        printf("data: %d\n",ptr->data);
        ptr=ptr->next;
    } while (ptr!=head);
    
}

struct node * insertAtFirst(struct Node *head,int data)
{
    struct Node *ptr=(struct Node *)malloc(sizeof(struct Node));
    ptr->data=data;
    struct Node *p=head->next;
    while(p->next!=head)
    {
        p=p->next;
    }
    p->next=ptr;
    ptr->next=head;
    head=ptr;
    return head;

}

struct Node * insertAtBetween(struct Node *head,int index,int data)
 {
     struct Node *ptr=(struct Node *)malloc(sizeof(struct Node));
     struct Node*p=head;
     ptr->data=data;
     int i=0;
     while(i!=index-1)
     {
          p=p->next;
          i++;
     }
     
     ptr->data=data;
     ptr->next=p->next;
     p->next=ptr;
     return head;
 }

 struct Node * InsertAtEnd(struct Node *head,int data)
 {
     struct Node * ptr = (struct Node *) malloc(sizeof(struct Node));
     ptr->data=data;
     struct Node *p=head;
     while(p->next !=head)
     {
         p=p->next;

     }
     p->next=ptr;
     ptr->next=head;
     return head;


 }

 struct Node * insertAtAfter(struct Node *head,struct Node *prevNode,int data)
 {
     struct Node *ptr=(struct Node *)malloc(sizeof(struct Node));
     ptr->data=data;
     ptr->next=prevNode->next;
     prevNode->next=ptr;
     return head;

 }


 
int main(){
    
    struct Node *head;
    struct Node *second;
    struct Node *third;
    struct Node *fourth;
 
    // Allocate memory for nodes in the linked list in Heap
    head = (struct Node *) malloc(sizeof(struct Node));
    second = (struct Node *) malloc(sizeof(struct Node));
    third = (struct Node *) malloc(sizeof(struct Node));
    fourth = (struct Node *) malloc(sizeof(struct Node));
 
    // Link first and second nodes
    head->data = 4;
    head->next = second;
 
    // Link second and third nodes
    second->data = 3;
    second->next = third;
 
    // Link third and fourth nodes
    third->data = 6;
    third->next = fourth;
 
    // Terminate the list at the third node
    fourth->data = 1;
    fourth->next = head;
     
    printf("Before Insertion\n");
    Traversal(head);

    printf("After Insertion\n");
    // head=insertAtFirst(head,40);
    // head=insertAtBetween(head,2,200);
    // head=InsertAtEnd(head,500);
    head=insertAtAfter(head,third,333);
    Traversal(head);

 
    return 0;
}
