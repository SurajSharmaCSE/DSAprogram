#include<stdio.h>

void display(int arr[],int n)
{
    for(int i=0;i<n ;i++)
    {
      printf("d",arr[i]);
    }
    printf("/n");
}

void indDeletion(int arr[],int size,int index)
{
    for(int i=index;i<size-1;i++)
    {
        arr[i]=arr[i+1];
    }
}

int main()
{
   int arr[100]={10,20,3,30,2,11,34};
   int size=7,index=1;
   indDeletion(arr,size,index);
   size -=1;
   display(arr,size);
   return 0;
}