#include<stdio.h>

int max(int a, int b) { return (a > b) ? a : b; }

int Knapsack(int CAP,int wt[],int val[],int n)
{
    if(n==0 || CAP==0)
    {
        return 0;
    }
    if(wt[n-1]<=CAP)
    {
        return max(val[n-1]+Knapsack(CAP-wt[n-1],wt,val,n-1),Knapsack(CAP,wt,val,n-1));
    }
}

int main()
{
    int val[] = { 60, 100, 120 };
    int wt[] = { 10, 20, 30 };
    int W = 50;
    int n = sizeof(val) / sizeof(val[0]);
    printf("%d",Knapsack(W, wt, val, n));
    return 0;
}