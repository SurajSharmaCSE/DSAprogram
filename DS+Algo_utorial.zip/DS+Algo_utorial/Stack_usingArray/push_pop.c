// #include<stdio.h>
// #include<stdlib.h>

// struct Stack
// {
//     int size;
//     int top;
//     int *arr;

// };

// int IsFull(struct Stack *ptr)
// {
//     if(ptr->top==ptr->size-1)
//     {
//         return 1;
//     }
//     else
//     {
//         return 0;
//     }
// }

// int  IsEmpty(struct Stack *ptr)
// {
//     if(ptr->top==-1)
//     {
//         return 1;
//     }
//     else
//     {
//         return 0;
//     }
// }

// void push(struct Stack *ptr,int value)
// {
//     if(IsFull(ptr))
//     {
//         printf("stack Overflow");
//     }
//     else
//     {  
//         ptr->top++;
//         ptr->arr[ptr->top]=value;
//         printf("%d is puhed",value);
//     }
// }

// int pop(struct Stack *ptr)
// {
//     if(IsEmpty(ptr))
//     {
//         printf("Stack Underflow");
//     }
//     else
//     {
//         int val=ptr->arr[ptr->top];
//         ptr->top=ptr->top-1;
//         printf("%d is poped",val);
//         return val;
//     }
// }

// int main()
// {
//     struct Stack *s;
//     // s.size=80;
//     // s.top=-1;
//     // s.arr=(int *)malloc(s.size*sizeof(int));

//     s->size=80;
//     s->top=-1;
//     s->arr=(int *)malloc(s->size*sizeof(int));
    
//     push(s,1);
    
     
    

//     return 0;

// }






#include<stdio.h>
#include<stdlib.h>
 
struct stack{
    int size ;
    int top;
    int * arr;
};

 
int isEmpty(struct stack* ptr){
    if(ptr->top == -1){
            return 1;
        }
        else{
            return 0;
        }
}
 
int isFull(struct stack* ptr){
    if(ptr->top == ptr->size - 1){
        return 1;
    }
    else{
        return 0;
    }
}
 
void push(struct stack* ptr, int val){
    if(isFull(ptr)){
        printf("Stack Overflow! Cannot push %d to the stack\n", val);
    }
    else{
        ptr->top++;
        ptr->arr[ptr->top] = val;
    }
}
 
int pop(struct stack* ptr){
    if(isEmpty(ptr)){
        printf("Stack Underflow! Cannot pop from the stack\n");
        return -1;
    }
    else{
        int val = ptr->arr[ptr->top];
        ptr->top--;
        return val;
    }
}
 
int main(){
    struct stack *sp = (struct stack *) malloc(sizeof(struct stack));
    sp->size = 10;
    sp->top = -1;
    sp->arr = (int *) malloc(sp->size * sizeof(int));
    printf("Stack has been created successfully\n");
    push(sp,10);
    push(sp,20);
    push(sp,30);
    push(sp,40);
    printf("%d is poped from stack\n",pop(sp));
    printf("%d is poped from stack\n",pop(sp));
    printf("%d is poped from stack\n",pop(sp));
    printf("%d is poped from stack\n",pop(sp));
    printf("%d is poped from stack\n",pop(sp));
    return 0;
}

