#include<stdio.h>
#include<stdlib.h>

struct Node
{
    int data;
    struct Node *next;
};

void LinkedlistTraversal(struct Node *ptr)
{
    while(ptr !=NULL)
     {
         printf("%d\n",ptr->data);
         ptr=ptr->next;
     }

}
struct Node * insertAtFirst(struct Node *head, int data){
    struct Node * ptr = (struct Node *) malloc(sizeof(struct Node));
    ptr->data = data;

    ptr->next = head;
    return ptr; 
}

struct Node * insertAtBetween(struct Node *head,int index,int data)
 {
     struct Node *ptr=(struct Node *)malloc(sizeof(struct Node));
     struct Node*p=head;
     ptr->data=data;
     int i=0;
     while(i!=index-1)
     {
          p=p->next;
          i++;
     }
     
     ptr->data=data;
     ptr->next=p->next;
     p->next=ptr;
     return head;
 }

 struct Node * InsertAtEnd(struct Node *head,int data)
 {
     struct Node * ptr = (struct Node *) malloc(sizeof(struct Node));
     ptr->data=data;
     struct Node *p=head;
     while(p->next !=NULL)
     {
         p=p->next;

     }
     p->next=ptr;
     ptr->next=NULL;
     return head;


 }

 struct Node * insertAtAfter(struct Node *head,struct Node *prevNode,int data)
 {
     struct Node *ptr=(struct Node *)malloc(sizeof(struct Node));
     ptr->data=data;
     ptr->next=prevNode->next;
     prevNode->next=ptr;
     return head;

 }

int main()
{
    struct Node *First;
    struct Node *Second;
    struct Node *third;

    First=(struct Node*)malloc(sizeof(struct Node));
    Second=(struct Node*)malloc(sizeof(struct Node));
    third=(struct Node*)malloc(sizeof(struct Node));

    //link first and Second Node
     
    First->data=10;
    First->next=Second;

    //Link second and third
    Second->data=30;
    Second->next=third;

    //Link second and third

    third->data=50;
    third->next=NULL;
    printf("before Inserion\n");
     LinkedlistTraversal(First);

    printf("After Insertion\n");
    // First=insertAtFirst(First,100);
    // First=insertAtEnd(First,100);
       First=insertAtAfter(First,Second,1111);
       LinkedlistTraversal(First);
}   
