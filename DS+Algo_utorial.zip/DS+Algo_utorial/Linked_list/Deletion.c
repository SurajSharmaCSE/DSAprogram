#include<stdio.h>
#include<stdlib.h>

struct node
{
    int data;
    struct node *next;
};

void Traversal(struct node *ptr)
{
    while(ptr !=NULL)
    {
        printf("Element %d\n",ptr->data);
        ptr=ptr->next;
    }
    

}
struct node * DeleteAtFirstNode(struct node *head)
{
    struct node *ptr=head;
    head=head->next;
    free(ptr);
    return head;
}

struct node * DeleteInBetween(struct node * head,int index)
{
    struct node *p=head;
    struct node *q=head->next;
    for (int i = 0; i < index-1; i++)
    {
        p=p->next;
        q=q->next;
    }
    p->next=q->next;
    free(q);
    return head;
    
    
}

struct node * DeleteAtLastNode(struct node *head)
{
    struct node *p=head;
    struct node *q=head->next;

    while(q->next!=NULL)
    {
        p=p->next;
        q=q->next;

    }
    p->next=NULL;
    free(q);

    return head;

}

// Case 4: Deleting the element with a given value from the linked list
struct node * deleteByValue(struct node * head, int value){
    struct node *p = head;
    struct node *q = head->next;
    while(q->data!=value && q->next!= NULL)
    {
        p = p->next;
        q = q->next;
    }
    
    if(q->data == value){
        p->next = q->next;
        free(q);
    }
    return head;
}


int main()
{

    // LinkedList Creation Start

    struct node *First;
    struct node *Second;
    struct node *third;
    struct node *forth;

    First=(struct node*)malloc(sizeof(struct node));
    Second=(struct node *) malloc(sizeof(struct node));
    third=(struct node *) malloc(sizeof(struct node));
    forth=(struct node *) malloc(sizeof(struct node));

    //link first and second node
     First->data=10;
     First->next=Second;

    //link second and third;
    Second->data=20;
    Second->next=third;

    // link third and fourth
    third->data=30;
    third->next=forth;

    //terminate fourth node

    forth->data=40;
    forth->next=NULL;


    //Linked List Creation End

    printf("Before Deletion\n");
    Traversal(First);
    printf("After dletion\n");
    // First=DeleteAtFirstNode(First);
    // First=DeleteInBetween(First,2);
    // First=DeleteAtLastNode(First);
    First=deleteByValue(First,30);
     Traversal(First);
     


}
